﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net;
using System.Net.Sockets;
public class Client : Singleton<Client>
{
    void Awake()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
