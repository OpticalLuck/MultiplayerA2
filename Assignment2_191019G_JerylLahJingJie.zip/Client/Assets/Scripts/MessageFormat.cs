﻿using UnityEngine;
using TMPro;
public class MessageFormat : MonoBehaviour
{
    public TMP_Text Name;
    public TMP_Text Time;
    public TMP_Text Content;
}
